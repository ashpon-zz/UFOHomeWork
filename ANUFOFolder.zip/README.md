# A Dynamic HTML Table

## Instructions

### Part I

* Use HTML, Bootstrap, and JavaScript to render a dynamically created table containing the data in `addressData.js`. It should look something like this. For now, don't worry about creating a search field.

  ![table.png](table.png)

### Part II

* If you've finished populating the table rows, implement a search function (by state) into your page. 

* You may use the `filter()` method that you've learned, or alternatively, an `if` statement.

  ![filter.png](filter.png)

## Bonus

* If you finish Parts I and II, try to implement a multiple search function, e.g. the ability to search by state and city.
